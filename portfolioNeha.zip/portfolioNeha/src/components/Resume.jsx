// import React, { useState } from 'react';

// // eslint-disable-next-line react/prop-types
// const QualificationDetail = ({ title, institution, year, details }) => {
//   const [showDetails, setShowDetails] = useState(false);

//   return (
//     <div>
//       <h3 className="text-xl font-semibold">{title}</h3>
//       <p className="text-gray-600">{institution}, {year}</p>
//       <button onClick={() => setShowDetails(!showDetails)} className="text-green-500">
//         {showDetails ? 'Hide Details' : 'View Details'}
//       </button>
//       {showDetails && (
//         <div className="text-gray-700 mt-2">
//           <p>{details}</p>
//         </div>
//       )}
//     </div>
//   );
// };

// // eslint-disable-next-line react/prop-types
// const ExperienceDetail = ({ company, title, duration, details }) => {
//   const [showDetails, setShowDetails] = useState(false);

//   return (
//     <div>
//       <h3 className="text-xl font-semibold">{company}</h3>
//       <p className="text-gray-600">{title}, {duration}</p>
//       <button onClick={() => setShowDetails(!showDetails)} className="text-green-500">
//         {showDetails ? 'Hide Details' : 'View Details'}
//       </button>
//       {showDetails && (
//         <div className="text-gray-700 mt-2">
//           <p>{details}</p>
//         </div>
//       )}
//     </div>
//   );
// };

// const Resume = () => {
//   return (
//     <div className="p-6">
//       <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
//         {/* Summary and Qualifications Column */}
//         <div>
//           {/* Summary Section */}
//           <section className="mb-8">
//             <h2 className="text-2xl font-bold mb-4">Summary</h2>
//             <p className="text-gray-700">
//               Professional front-end developer with over X years of experience in creating dynamic and responsive web applications using React, TypeScript, and modern CSS frameworks.
//             </p>
//           </section>

//           {/* Qualifications Section */}
//           <section className="mb-8">
//             <h2 className="text-2xl font-bold mb-4">Qualifications</h2>
//             <div className="space-y-4">
//               <QualificationDetail
//                 title="Bachelor's Degree"
//                 institution="REC Sonbhadra"
//                 year="2023"
//                 details="Graduated with an 8.01 CGPA."
//               />
//               <QualificationDetail
//                 title="Intermediate"
//                 institution="Sun Shine Public School"
//                 year="2017"
//                 details="Graduated with 76.4%."
//               />
//               <QualificationDetail
//                 title="High School"
//                 institution="Sun Shine Public School"
//                 year="2015"
//                 details="Graduated with 93.1%."
//               />
//             </div>
//           </section>
//         </div>

//         {/* Experience Column */}
//         <div>
//           <section className="mb-8">
//             <h2 className="text-2xl font-bold mb-4">Experience</h2>
//             <div className="space-y-4">
//               <ExperienceDetail
//                 company="DRP Labs"
//                 title="Full-time"
//                 duration="2023 - Present"
//                 details="Working on various front-end development projects using modern web technologies."
//               />
//               <ExperienceDetail
//                 company="Fynd Academy"
//                 title="Internship"
//                 duration="2023"
//                 details="Interned as a front-end developer, contributing to multiple projects."
//               />
//               <ExperienceDetail
//                 company="Digitrix"
//                 title="Internship"
//                 duration="2022"
//                 details="Gained experience in front-end development and worked on several key projects."
//               />
//             </div>
//           </section>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Resume;




const Resume = () => {
  return (
    <div>
      <section id="resume" className="mt-6 overflow-y-auto h-[calc(100vh-64px)] bg-slate-900 font-serif text-gray-50 mx-28 px-28 py-8">
    <div className="p-30 bg-black">

      <div className="section-title">
        <h2>Resume</h2>
        <p>Check My Resume</p>
      </div>

      <div className="row">
        <div className="col-lg-6">
          <h3 className="resume-title">Sumary</h3>
          <div className="resume-item pb-0">
            <h4>Alice Barkley</h4>
            <p><em>Innovative and deadline-driven Graphic Designer with 3+ years of experience designing and developing user-centered digital/print marketing material from initial concept to final, polished deliverable.</em></p>
            <p>
            </p><ul>
              <li>Portland par 127,Orlando, FL</li>
              <li>(123) 456-7891</li>
              <li>alice.barkley@example.com</li>
            </ul>
            
          </div>

          <h3 className="resume-title">Education</h3>
          <div className="relative ">
            <h4>Master of Fine Arts &amp; Graphic Design</h4>
            <h5>2015 - 2016</h5>
            <p><em>Rochester Institute of Technology, Rochester, NY</em></p>
            <p>Qui deserunt veniam. Et sed aliquam labore tempore sed quisquam iusto autem sit. Ea vero voluptatum qui ut dignissimos deleniti nerada porti sand markend</p>
          </div>
          <div className="relative">
            <h4>Bachelor of Fine Arts &amp; Graphic Design</h4>
            <h5>2010 - 2014</h5>
            <p><em>Rochester Institute of Technology, Rochester, NY</em></p>
            <p>Quia nobis sequi est occaecati aut. Repudiandae et iusto quae reiciendis et quis Eius vel ratione eius unde vitae rerum voluptates asperiores voluptatem Earum molestiae consequatur neque etlon sader mart dila</p>
          </div>
        </div>
        <div className="">
          <h3 className="">Professional Experience</h3>
          <div className="">
            <h4>Senior graphic design specialist</h4>
            <h5>2019 - Present</h5>
            <p><em>Experion, New York, NY </em></p>
            <p>
            </p><ul>
              <li>Lead in the design, development, and implementation of the graphic, layout, and production communication materials</li>
              <li>Delegate tasks to the 7 members of the design team and provide counsel on all aspects of the project. </li>
              <li>Supervise the assessment of all graphic materials in order to ensure quality and accuracy of the design</li>
              <li>Oversee the efficient use of production project budgets ranging from $2,000 - $25,000</li>
            </ul>
            
          </div>
          <div className="">
            <h4>Graphic design specialist</h4>
            <h5>2017 - 2018</h5>
            <p><em>Stepping Stone Advertising, New York, NY</em></p>
            <p>
            </p>
            <ul>
              <li>Developed numerous marketing programs (logos, brochures,infographics, presentations, and advertisements).</li>
              <li>Managed up to 5 projects or tasks at a given time while under pressure</li>
              <li>Recommended and consulted with clients on the most appropriate graphic design</li>
              <li>Created 4+ design presentations and proposals a month for clients and account managers</li>
            </ul>
            <p></p>
          </div>
        </div>
      </div>

    </div>
  </section>
      
    </div>
  )
}

export default Resume

