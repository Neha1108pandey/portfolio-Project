

const Portfolio = () => {
  return (
    <div className="h-screen bg-slate-950 font-serif text-gray-50">
    <h1 className="text-4xl font-bold mb-4 flex justify-center mt-64">Portfolio</h1>
    <p className="text-2xl font-semibold mb-4 flex justify-center">
      This is the portfolio page content.
    </p>
  </div>

  )
}

export default Portfolio
