
import { FaMapMarkerAlt, FaEnvelope, FaPhone, FaInstagram, FaLinkedin, FaFacebook } from 'react-icons/fa';

const ContactPage = () => {
  return (
    <div className="mt-6 overflow-y-auto h-[calc(100vh-64px)] bg-slate-900 font-serif text-gray-50 mx-28 px-28 py-8">
           <h1 className="text-2xl font-bold mb-4 flex justify-start hover:text-green-500 hover:underline hover:underline-offset-8 hover:opacity-100">CONTACT</h1>
           <h1 className="text-4xl font-bold space-x-2 mb-10 flex justify-start ml- font-sans ">CONTACT ME.</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Address Card */}
        <div className="flex items-center bg-gray-800 p-6 rounded-lg shadow-md">
          <div className="bg-gray-700 p-4 rounded-full mr-4">
            <FaMapMarkerAlt className="text-green-500 text-3xl" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Address</h2>
            <p>Ghazipur, UP, India</p>
          </div>
        </div>
        
        {/* Email Card */}
        <div className="flex items-center bg-gray-800 p-6 rounded-lg shadow-md">
          <div className="bg-gray-700 p-4 rounded-full mr-4">
            <FaEnvelope className="text-green-500 text-3xl" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Email Me</h2>
            <p>nehap2680@gmail.com</p>
          </div>
        </div>
        
        {/* Call Me Card */}
        <div className="flex items-center bg-gray-800 p-6 rounded-lg shadow-md">
          <div className="bg-gray-700 p-4 rounded-full mr-4">
            <FaPhone className="text-green-500 text-3xl" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Call Me</h2>
            <p>(+91) 8799042424</p>
          </div>
        </div>
        
        {/* Social Profiles Card */}
        <div className="flex items-center bg-gray-800 p-6 rounded-lg shadow-md">
          <div>
            <h2 className="text-xl font-bold mb-2">Follow Me</h2>
            <div className="flex space-x-4">
              <a href="https://www.instagram.com/nehap2680/" target="_blank" rel="noopener noreferrer">
                <div className="bg-gray-700 p-3 rounded-full">
                  <FaInstagram className="text-green-500 text-3xl" />
                </div>
              </a>
              <a href="https://www.linkedin.com/in/neha-pandey-1b6289194/" target="_blank" rel="noopener noreferrer">
                <div className="bg-gray-700 p-3 rounded-full">
                  <FaLinkedin className="text-green-500 text-3xl" />
                </div>
              </a>
              <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer">
                <div className="bg-gray-700 p-3 rounded-full">
                  <FaFacebook className="text-green-500 text-3xl" />
                </div>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Contact Form */}
      <div className="mt-8 bg-gray-800 p-6 rounded-lg shadow-md">
        <form>
          <div className="grid grid-cols-2 gap-4 ">
            <input type="text" placeholder="Name" className="p-2 rounded bg-gray-700 text-white" />
            <input type="email" placeholder="Email" className="p-2 rounded bg-gray-700 text-white" />
          </div>
          <div className="grid grid-cols-1 gap-4 py-4">
            <input type="text" placeholder="Subject" className="p-2 rounded bg-gray-700 text-white" />
            <textarea placeholder="Message" className="p-2 rounded bg-gray-700 text-white"></textarea>
            <button type="submit" className="bg-green-500 p-2 rounded text-white">Send</button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default ContactPage;
