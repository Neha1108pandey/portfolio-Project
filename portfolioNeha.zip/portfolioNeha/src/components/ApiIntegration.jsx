// import { useState } from "react";

import { useState } from "react";

function ApiIntegration() {
  
const [postData,setPostData]=useState([]);
// console.log(fetch('https://dummyjson.com/post'));
 // const [postData,setPostData]=useState
// Could be GET or POST/PUT/PATCH/DELETE

 

fetch('https://dummyjson.com/post')
.then((res) => res.json()).then(data=>setPostData(data.posts));

console.log(postData);

// Could be GET or POST/PUT/PATCH/DELETE
// fetch('//dummyjson.com/test')
// .then(res => res.json())
// .then(console.log);

/* { status: 'ok', method: 'GET' } */
/* { status: 'ok', method: 'GET' } */
  return (
    <div>

    </div>
  )
}

export default ApiIntegration
