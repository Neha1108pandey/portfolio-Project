

const Services = () => {
  return (
    <div>
      <h1>servics</h1>
    </div>
  )
}

export default Services
