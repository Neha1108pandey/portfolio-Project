// src/components/Headers
import pic1 from '../assets/picture2.png';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faLinkedin, faGithub, faInstagram } from '@fortawesome/free-brands-svg-icons';

const Headers = () => {
  return (
    <div className="flex h-screen bg-slate-950 font-serif overflow-hidden ">
      {/* Left side */}
      <div className="w-1/2 bg-slate-950 p-8">
        <h1 className="text-7xl font-bold mb-4 flex justify-center mt-52 text-gray-50">NEHA PANDEY</h1>
        <p className="text-2xl font-semibold mb-4 flex justify-center text-gray-50">
          I am a passionate <span className='underline text-green-500'>Web Developer</span>  from India
        </p>
        {/* <ul className="flex justify-center space-x-8 mt-8 text-gray-500 h text-xl opacity-75">
          <li className="mb-2  hover:text-green-500 hover:underline hover:underline-offset-8 hover:opacity-100">
            <a href="#">Home</a>
          </li>
          <li className="mb-2 hover:text-green-500 hover:underline hover:underline-offset-8 hover:opacity-100">
            <a href="#">About</a>
          </li>
          <li className="mb-2 hover:text-green-500 hover:underline hover:underline-offset-8 hover:opacity-100">
            <a href="#">Resume</a>
          </li>
          <li className="mb-2 hover:text-green-500 hover:underline hover:underline-offset-8 hover:opacity-100">
            <a href="#">Services</a>
          </li>
          <li className="mb-2 hover:text-green-500 hover:underline hover:underline-offset-8 hover:opacity-100">
            <a href="#">Portfolio</a>
          </li>
          <li className="mb-2 hover:text-green-500 hover:underline hover:underline-offset-8 hover:opacity-100">
            <a href="#">Contact</a>
          </li>
        </ul> */}
        <div className="flex justify-center space-x-6 mt-8 text-gray-50 text-3xl">
          <a href="https://www.linkedin.com/in/neha-pandey-1b6289194/" 
            target="_blank" rel="noopener noreferrer"
            className='rounded-3xl p-2 px-3 bg-slate-300 bg-opacity-15 hover:bg-green-700'>
            <FontAwesomeIcon icon={faLinkedin} />
          </a>
          <a href="https://github.com/Neha1108pandey" target="_blank" rel="noopener noreferrer"
            className='rounded-3xl p-2 px-3 bg-slate-300 bg-opacity-15 hover:bg-green-700'>
            <FontAwesomeIcon icon={faGithub} />
          </a>
          <a href="https://app.netlify.com/teams/yourprofile/overview" target="_blank" rel="noopener noreferrer"
            className='rounded-3xl p-2 px-3 bg-slate-300 bg-opacity-15 hover:bg-green-700'>
            <FontAwesomeIcon icon={faInstagram} /> {/* Replace with the appropriate Netlify icon */}
          </a>
        </div>
      </div>
      
      {/* Right side */}
      <div className="w-96 flex justify-center items-center">
        <img
          src={pic1}
          alt="John Doe"
          className="ml-48 max-h-full"
        />
      </div>
    </div>
  );
};

export default Headers;
