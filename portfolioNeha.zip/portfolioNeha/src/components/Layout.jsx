// src/components/Layout.jsx

import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';

const Layout = ({ children }) => {
  return (
    <div className="flex flex-col h-screen bg-slate-950 font-serif overflow-hidden ">
      <nav className="bg-slate-300 bg-opacity-15 p-4">
        <ul className="flex justify-center space-x-8 text-gray-500 text-xl opacity-75">
          <li className="hover:text-green-500 hover:underline hover:underline-offset-8 hover:opacity-100">
            <Link to="/">Home</Link>
          </li>
          <li className="hover:text-green-500 hover:underline hover:underline-offset-8 hover:opacity-100">
            <Link to="/about">About</Link>
          </li>
          <li className="hover:text-green-500 hover:underline hover:underline-offset-8 hover:opacity-100">
            <Link to="/resume">Resume</Link>
          </li>
          <li className="hover:text-green-500 hover:underline hover:underline-offset-8 hover:opacity-100">
            <Link to="/services">Services</Link>
          </li>
          <li className="hover:text-green-500 hover:underline hover:underline-offset-8 hover:opacity-100">
            <Link to="/portfolio">Portfolio</Link>
          </li>
          <li className="hover:text-green-500 hover:underline hover:underline-offset-8 hover:opacity-100">
            <Link to="/contact">Contact</Link>
          </li>
        </ul>
      </nav>
      <main className="flex-grow">
        {children}
      </main>
    </div>
  );
};

Layout.propTypes = {
  children: PropTypes.node.isRequired,
};

export default Layout;
