import pic1 from '../assets/aboutpic.png';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faGreaterThan } from '@fortawesome/free-solid-svg-icons';
import { faCode, faLaptopCode, faPalette, faServer, faUsers, faBriefcase, faClock, faProjectDiagram, faDatabase } from '@fortawesome/free-solid-svg-icons'; 
import { faJsSquare } from '@fortawesome/free-brands-svg-icons';
import { useInView } from 'react-intersection-observer';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import '../App.css';
import userIcon from '../assets/user-icon.png';

const testimonials = [
  {
    id: 1,
    name: 'John Doe',
    position: 'CEO at Company',
    review: 'This web developer did an amazing job! Highly recommended.',
    image: userIcon
  },
  {
    id: 2,
    name: 'Jane Smith',
    position: 'CTO at Company',
    review: 'Excellent skills and great attention to detail.',
    image: userIcon
  },
];

const About = () => {
  const skills = [
    { name: 'HTML', level: '80%' },
    { name: 'CSS', level: '75%' },
    { name: 'JavaScript', level: '70%' },
    { name: 'React JS', level: '65%' },
    { name: 'TypeScript', level: '60%' },
    { name: 'Tailwind CSS', level: '70%' }
  ];

  const interests = [
    { icon: faCode, title: 'Web Developer' },
    { icon: faLaptopCode, title: 'Software Engineer' },
    { icon: faPalette, title: 'Front End Developer' },
    { icon: faDatabase, title: 'Backend Developer' },
    { icon: faJsSquare, title: 'MERN Developer' },
    { icon: faServer, title: 'Software Developer' },
    { icon: faUsers, title: 'Team Work' },
    { icon: faBriefcase, title: 'Freelance' },
    { icon: faClock, title: 'Part Time Work' },
    { icon: faProjectDiagram, title: 'Project Management' },
  ]

  const { ref, inView } = useInView({
    threshold: 0.1,
    triggerOnce: true
  });

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 2,
    slidesToScroll: 2,
    centerMode: true,
    centerPadding: '40px'
  };

  return (
    <div className="mt-6 overflow-y-auto h-[calc(100vh-64px)] bg-slate-900 font-serif text-gray-50 mx-28 px-28 py-8">
      <h1 className="text-2xl font-bold mb-4 flex justify-start hover:text-green-500 hover:underline hover:underline-offset-8 hover:opacity-100">ABOUT</h1>
      <h1 className="text-4xl font-bold space-x-2 mb-4 flex justify-start ml- font-sans">LEARN MORE ABOUT ME.</h1>
      <h1 className="text-3xl font-bold space-x-2 mb-4 flex justify-center text-green-500 font-sans mr-16 pt-6">Software Engineer</h1>
      
      <div className="flex">
        <div className="flex flex-col rounded-full w-56 h-56 bg-white object-cover">
          <img src={pic1} alt="Neha Pandey" className=" " />
        </div>
        
        <div className="w-3/4 pl-8">
          <div className="text-lg mb-4 font-sans ml-28">
            Hello! I am Neha Pandey, a passionate and dedicated software engineer with a keen interest in developing innovative and efficient software solutions.
          </div>
          <div className="flex space-y-2 space-x-42 pl-24">
            <div className="pl-4 pt-6">
              <ul>
                <li className="mb-2">
                  <FontAwesomeIcon icon={faGreaterThan} className="text-green-500" />
                  <strong className="pl-4 text-lg">Birthday:</strong>
                  <span className="pl-4 text-lg">11 August 2000</span>
                </li>
                <li className="mb-2">
                  <FontAwesomeIcon icon={faGreaterThan} className="text-green-500" />
                  <strong className="pl-4 text-lg">LinkedIn:</strong>
                  <span className="pl-4 text-lg">neha-pandey-1b6289194</span>
                </li>
                <li className="mb-2">
                  <FontAwesomeIcon icon={faGreaterThan} className="text-green-500" />
                  <strong className="pl-4 text-lg">Mobile:</strong>
                  <span className="pl-4 text-lg">8799042424</span>
                </li>
                <li className="mb-2">
                  <FontAwesomeIcon icon={faGreaterThan} className="text-green-500" />
                  <strong className="pl-4 text-lg">City:</strong>
                  <span className="pl-4 text-lg">Noida</span>
                </li>
              </ul>
            </div>

            <div className="pt-7">
              <ul>
                <li className="mb-2">
                  <FontAwesomeIcon icon={faGreaterThan} className="text-green-500" />
                  <strong className="pl-4 text-lg">Age:</strong>
                  <span className="pl-4 text-lg">24</span>
                </li>
                <li className="mb-2">
                  <FontAwesomeIcon icon={faGreaterThan} className="text-green-500" />
                  <strong className="pl-4 text-lg">Degree:</strong>
                  <span className="pl-4 text-lg">Btech</span>
                </li>
                <li className="mb-2">
                  <FontAwesomeIcon icon={faGreaterThan} className="text-green-500" />
                  <strong className="pl-4 text-lg">Email:</strong>
                  <span className="pl-4 text-lg">nehap2680@gmail.com</span>
                </li>
                <li className="mb-2">
                  <FontAwesomeIcon icon={faGreaterThan} className="text-green-500" />
                  <strong className="pl-4 text-lg">Freelance:</strong>
                  <span className="pl-4 text-lg">Available</span>
                </li>
              </ul>
            </div>
          </div>
          
          <p className="text-lg mb-4 font-sans mt-6 ml-28">I recently graduated with a degree in Computer Science and Engineering from Rajkiya Engineering College, Sonbhadra, where I honed my skills in software development, problem-solving, and teamwork.</p>
        </div>
      </div>

      <div className="pt-16" ref={ref}>
        <h1 className="text-2xl font-bold mb-4 ml-2 flex justify-start hover:text-green-500 hover:underline hover:underline-offset-8 hover:opacity-100">SKILLS</h1>
        <div className="flex flex-wrap pr-10">
          {skills.map(skill => (
            <div key={skill.name} className="w-1/2 p-3">
              <h3 className="font-semibold">{skill.name} - {inView ? skill.level : '0%'}</h3>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div className="bg-green-500 h-3 rounded-full transition-all duration-1000" style={{ width: inView ? skill.level : '0%' }}></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="pt-12">
        <h1 className="text-2xl pb-4 font-bold mb-4 ml-2 flex justify-start hover:text-green-500 hover:underline hover:underline-offset-8 hover:opacity-100">INTEREST</h1>
        <div className="grid grid-cols-3 gap-4">
          {interests.map(interest => (
            <div key={interest.title} className="bg-gray-800 p-4 rounded-lg flex flex-col items-center transform transition-transform duration-300 hover:scale-105 hover:rotate-3">
              <FontAwesomeIcon icon={interest.icon} className="bg-green-500 text-white text-4xl mb-2 p-2 rounded-full transform transition-transform duration-300 hover:scale-125" />
              <h3 className="text-xl font-semibold transform transition-transform duration-300 hover:scale-105">{interest.title}</h3>
            </div>
          ))}
        </div>
      </div>
{/* 
      <div className='pt-12'>
        <h1 className="text-2xl font-bold mb-4 ml-2 flex justify-start hover:text-green-500 hover:underline hover:underline-offset-8 hover:opacity-100">TESTIMONIAL</h1>
        <Slider {...settings}>
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className=" grid place-content-between rounded-lg shadow-lg p-6 m-4 bg-gray-800">
              <div className="flex items-center mb-4">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-20 h-20 rounded-full object-cover mr-4"
                />
                <div>
                  <h3 className="text-xl font-semibold text-white">{testimonial.name}</h3>
                  <p className="text-gray-400">{testimonial.position}</p>
                </div>
              </div>
              <blockquote className="text-gray-200 italic">{testimonial.review}</blockquote>
            </div>
          ))}
        </Slider>
      </div> */}
    </div>
  );
};

export default About;
