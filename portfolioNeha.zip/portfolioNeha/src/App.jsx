import Headers from './components/Headers'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css'
import Layout from './components/Layout';
import About from './components/About'
import Resume from './components/Resume'
import Services from './components/Services'
import Portfolio  from './components/Portfolio'
import Contact from './components/Contact';

function App() {
  

  return (
    <>
      <div>
      
      <Router>
      <Routes>
        <Route path="/" element={<Layout><Headers /></Layout>} />
        <Route path="/about" element={<Layout><About /></Layout>} />
        <Route path="/resume" element={<Layout><Resume /></Layout>} />
        <Route path="/services" element={<Layout><Services /></Layout>} />
        <Route path="/portfolio" element={<Layout><Portfolio /></Layout>} />
        <Route path="/contact" element={<Layout><Contact /></Layout>} />
      </Routes>
    </Router>

      </div>
      
      
    </>
  )
}

export default App
